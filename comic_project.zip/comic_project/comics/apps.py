from django.apps import AppConfig


class ComicsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'comics'
