# comics/urls.py

from django.urls import path
from . import views

urlpatterns = [
    path('create/', views.create_comic, name='create_comic'),
    path('', views.view_comics, name='view_comics'),
    path('view_details', views.detail_comics, name='view-details')
]
