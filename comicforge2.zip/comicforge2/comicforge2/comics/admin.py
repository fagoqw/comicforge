from django.contrib import admin
from .models import Comic, Panel


admin.site.register(Comic)
admin.site.register(Panel)
